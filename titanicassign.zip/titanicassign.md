

```python
# VARIABLE DESCRIPTIONS

# Pclass - Passenger Class (1 = 1st; 2 = 2nd; 3 = 3rd) 
# survival - Survival (0 = No; 1 = Yes) 
# name - Name 
# sex - Sex 
# age - Age 
# sibsp - Number of Siblings/Spouses Aboard 
# parch - Number of Parents/Children Aboard 
# ticket - Ticket Number 
# fare - Passenger Fare (British pound) 
# cabin - Cabin 
# embarked - Port of Embarkation (C = Cherbourg; Q = Queenstown; S = Southampton) 
# boat - Lifeboat 
# body - Body Identification Number 
# home.dest - Home/Destination
```


```python
import pandas as pd
import numpy as np
from numpy import random
import matplotlib.pyplot as plt

%matplotlib inline

```


```python
Location = "C:\\Users\Matthew\\Desktop\\titanic3 (1).csv"
```


```python
df = pd.read_csv(Location)
```


```python
df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pclass</th>
      <th>survived</th>
      <th>name</th>
      <th>sex</th>
      <th>age</th>
      <th>sibsp</th>
      <th>parch</th>
      <th>ticket</th>
      <th>fare</th>
      <th>cabin</th>
      <th>embarked</th>
      <th>boat</th>
      <th>body</th>
      <th>home.dest</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>Allen, Miss. Elisabeth Walton</td>
      <td>female</td>
      <td>29.0000</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>24160</td>
      <td>211.3375</td>
      <td>B5</td>
      <td>S</td>
      <td>2</td>
      <td>NaN</td>
      <td>St Louis, MO</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>Allison, Master. Hudson Trevor</td>
      <td>male</td>
      <td>0.9167</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>113781</td>
      <td>151.5500</td>
      <td>C22 C26</td>
      <td>S</td>
      <td>11</td>
      <td>NaN</td>
      <td>Montreal, PQ / Chesterville, ON</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>Allison, Miss. Helen Loraine</td>
      <td>female</td>
      <td>2.0000</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>113781</td>
      <td>151.5500</td>
      <td>C22 C26</td>
      <td>S</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Montreal, PQ / Chesterville, ON</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>Allison, Mr. Hudson Joshua Creighton</td>
      <td>male</td>
      <td>30.0000</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>113781</td>
      <td>151.5500</td>
      <td>C22 C26</td>
      <td>S</td>
      <td>NaN</td>
      <td>135.0</td>
      <td>Montreal, PQ / Chesterville, ON</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>Allison, Mrs. Hudson J C (Bessie Waldo Daniels)</td>
      <td>female</td>
      <td>25.0000</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>113781</td>
      <td>151.5500</td>
      <td>C22 C26</td>
      <td>S</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Montreal, PQ / Chesterville, ON</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.describe()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pclass</th>
      <th>survived</th>
      <th>age</th>
      <th>sibsp</th>
      <th>parch</th>
      <th>fare</th>
      <th>body</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1309.000000</td>
      <td>1309.000000</td>
      <td>1046.000000</td>
      <td>1309.000000</td>
      <td>1309.000000</td>
      <td>1308.000000</td>
      <td>121.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2.294882</td>
      <td>0.381971</td>
      <td>29.881135</td>
      <td>0.498854</td>
      <td>0.385027</td>
      <td>33.295479</td>
      <td>160.809917</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.837836</td>
      <td>0.486055</td>
      <td>14.413500</td>
      <td>1.041658</td>
      <td>0.865560</td>
      <td>51.758668</td>
      <td>97.696922</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.166700</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>1.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>2.000000</td>
      <td>0.000000</td>
      <td>21.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>7.895800</td>
      <td>72.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>3.000000</td>
      <td>0.000000</td>
      <td>28.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>14.454200</td>
      <td>155.000000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>3.000000</td>
      <td>1.000000</td>
      <td>39.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>31.275000</td>
      <td>256.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>3.000000</td>
      <td>1.000000</td>
      <td>80.000000</td>
      <td>8.000000</td>
      <td>9.000000</td>
      <td>512.329200</td>
      <td>328.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
Categorical = ['name', 'sex', 'cabin', 'embarked','home.dest']
```


```python
df[Categorical].describe()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>name</th>
      <th>sex</th>
      <th>cabin</th>
      <th>embarked</th>
      <th>home.dest</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1309</td>
      <td>1309</td>
      <td>295</td>
      <td>1307</td>
      <td>745</td>
    </tr>
    <tr>
      <th>unique</th>
      <td>1307</td>
      <td>2</td>
      <td>186</td>
      <td>3</td>
      <td>369</td>
    </tr>
    <tr>
      <th>top</th>
      <td>Kelly, Mr. James</td>
      <td>male</td>
      <td>C23 C25 C27</td>
      <td>S</td>
      <td>New York, NY</td>
    </tr>
    <tr>
      <th>freq</th>
      <td>2</td>
      <td>843</td>
      <td>6</td>
      <td>914</td>
      <td>64</td>
    </tr>
  </tbody>
</table>
</div>




```python
def score_to_numeric(x):
    if x=='female':
        return 1
    if x=='male':
        return 0
```


```python
# convert the sex category to numeric for analysis
df['sex-val'] = df['sex'].apply(score_to_numeric)
```


```python
df.tail()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pclass</th>
      <th>survived</th>
      <th>name</th>
      <th>sex</th>
      <th>age</th>
      <th>sibsp</th>
      <th>parch</th>
      <th>ticket</th>
      <th>fare</th>
      <th>cabin</th>
      <th>embarked</th>
      <th>boat</th>
      <th>body</th>
      <th>home.dest</th>
      <th>sex-val</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1305</th>
      <td>3.0</td>
      <td>0.0</td>
      <td>Zabour, Miss. Thamine</td>
      <td>female</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>2665</td>
      <td>14.4542</td>
      <td>NaN</td>
      <td>C</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>1306</th>
      <td>3.0</td>
      <td>0.0</td>
      <td>Zakarian, Mr. Mapriededer</td>
      <td>male</td>
      <td>26.5</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2656</td>
      <td>7.2250</td>
      <td>NaN</td>
      <td>C</td>
      <td>NaN</td>
      <td>304.0</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1307</th>
      <td>3.0</td>
      <td>0.0</td>
      <td>Zakarian, Mr. Ortin</td>
      <td>male</td>
      <td>27.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2670</td>
      <td>7.2250</td>
      <td>NaN</td>
      <td>C</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1308</th>
      <td>3.0</td>
      <td>0.0</td>
      <td>Zimmerman, Mr. Leo</td>
      <td>male</td>
      <td>29.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>315082</td>
      <td>7.8750</td>
      <td>NaN</td>
      <td>S</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1309</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
df['cabin'].describe()
```




    count             295
    unique            186
    top       C23 C25 C27
    freq                6
    Name: cabin, dtype: object




```python
df['cabin'].unique()
```




    array(['B5', 'C22 C26', 'E12', 'D7', 'A36', 'C101', nan, 'C62 C64', 'B35',
           'A23', 'B58 B60', 'D15', 'C6', 'D35', 'C148', 'C97', 'B49', 'C99',
           'C52', 'T', 'A31', 'C7', 'C103', 'D22', 'E33', 'A21', 'B10', 'B4',
           'E40', 'B38', 'E24', 'B51 B53 B55', 'B96 B98', 'C46', 'E31', 'E8',
           'B61', 'B77', 'A9', 'C89', 'A14', 'E58', 'E49', 'E52', 'E45', 'B22',
           'B26', 'C85', 'E17', 'B71', 'B20', 'A34', 'C86', 'A16', 'A20',
           'A18', 'C54', 'C45', 'D20', 'A29', 'C95', 'E25', 'C111',
           'C23 C25 C27', 'E36', 'D34', 'D40', 'B39', 'B41', 'B102', 'C123',
           'E63', 'C130', 'B86', 'C92', 'A5', 'C51', 'B42', 'C91', 'C125',
           'D10 D12', 'B82 B84', 'E50', 'D33', 'C83', 'B94', 'D49', 'D45',
           'B69', 'B11', 'E46', 'C39', 'B18', 'D11', 'C93', 'B28', 'C49',
           'B52 B54 B56', 'E60', 'C132', 'B37', 'D21', 'D19', 'C124', 'D17',
           'B101', 'D28', 'D6', 'D9', 'B80', 'C106', 'B79', 'C47', 'D30',
           'C90', 'E38', 'C78', 'C30', 'C118', 'D36', 'D48', 'D47', 'C105',
           'B36', 'B30', 'D43', 'B24', 'C2', 'C65', 'B73', 'C104', 'C110',
           'C50', 'B3', 'A24', 'A32', 'A11', 'A10', 'B57 B59 B63 B66', 'C28',
           'E44', 'A26', 'A6', 'A7', 'C31', 'A19', 'B45', 'E34', 'B78', 'B50',
           'C87', 'C116', 'C55 C57', 'D50', 'E68', 'E67', 'C126', 'C68', 'C70',
           'C53', 'B19', 'D46', 'D37', 'D26', 'C32', 'C80', 'C82', 'C128',
           'E39 E41', 'D', 'F4', 'D56', 'F33', 'E101', 'E77', 'F2', 'D38', 'F',
           'F G63', 'F E57', 'F E46', 'F G73', 'E121', 'F E69', 'E10', 'G6',
           'F38'], dtype=object)




```python
char_cabin = df["Cabin"].astype(str)
```


```python
cabin_level = np.array([cabin[0] for cabin in char_cabin])
```


```python
cabin_level = pd.Categorical(cabin_level)
```


```python
cabin_level .describe()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>counts</th>
      <th>freqs</th>
    </tr>
    <tr>
      <th>categories</th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>A</th>
      <td>22</td>
      <td>0.016794</td>
    </tr>
    <tr>
      <th>B</th>
      <td>65</td>
      <td>0.049618</td>
    </tr>
    <tr>
      <th>C</th>
      <td>94</td>
      <td>0.071756</td>
    </tr>
    <tr>
      <th>D</th>
      <td>46</td>
      <td>0.035115</td>
    </tr>
    <tr>
      <th>E</th>
      <td>41</td>
      <td>0.031298</td>
    </tr>
    <tr>
      <th>F</th>
      <td>21</td>
      <td>0.016031</td>
    </tr>
    <tr>
      <th>G</th>
      <td>5</td>
      <td>0.003817</td>
    </tr>
    <tr>
      <th>T</th>
      <td>1</td>
      <td>0.000763</td>
    </tr>
    <tr>
      <th>n</th>
      <td>1015</td>
      <td>0.774809</td>
    </tr>
  </tbody>
</table>
</div>




```python
df["cabin"] = cabin_level 
```


```python
df.tail()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pclass</th>
      <th>survived</th>
      <th>name</th>
      <th>sex</th>
      <th>age</th>
      <th>sibsp</th>
      <th>parch</th>
      <th>ticket</th>
      <th>fare</th>
      <th>cabin</th>
      <th>embarked</th>
      <th>boat</th>
      <th>body</th>
      <th>home.dest</th>
      <th>sex-val</th>
      <th>Cabin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1305</th>
      <td>3.0</td>
      <td>0.0</td>
      <td>Zabour, Miss. Thamine</td>
      <td>female</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>2665</td>
      <td>14.4542</td>
      <td>n</td>
      <td>C</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1.0</td>
      <td>nan</td>
    </tr>
    <tr>
      <th>1306</th>
      <td>3.0</td>
      <td>0.0</td>
      <td>Zakarian, Mr. Mapriededer</td>
      <td>male</td>
      <td>26.5</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2656</td>
      <td>7.2250</td>
      <td>n</td>
      <td>C</td>
      <td>NaN</td>
      <td>304.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>nan</td>
    </tr>
    <tr>
      <th>1307</th>
      <td>3.0</td>
      <td>0.0</td>
      <td>Zakarian, Mr. Ortin</td>
      <td>male</td>
      <td>27.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>2670</td>
      <td>7.2250</td>
      <td>n</td>
      <td>C</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>nan</td>
    </tr>
    <tr>
      <th>1308</th>
      <td>3.0</td>
      <td>0.0</td>
      <td>Zimmerman, Mr. Leo</td>
      <td>male</td>
      <td>29.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>315082</td>
      <td>7.8750</td>
      <td>n</td>
      <td>S</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>nan</td>
    </tr>
    <tr>
      <th>1309</th>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>n</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>nan</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.head()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pclass</th>
      <th>survived</th>
      <th>name</th>
      <th>sex</th>
      <th>age</th>
      <th>sibsp</th>
      <th>parch</th>
      <th>ticket</th>
      <th>fare</th>
      <th>cabin</th>
      <th>embarked</th>
      <th>boat</th>
      <th>body</th>
      <th>home.dest</th>
      <th>sex-val</th>
      <th>Cabin</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>Allen, Miss. Elisabeth Walton</td>
      <td>female</td>
      <td>29.0000</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>24160</td>
      <td>211.3375</td>
      <td>B</td>
      <td>S</td>
      <td>2</td>
      <td>NaN</td>
      <td>St Louis, MO</td>
      <td>1.0</td>
      <td>B5</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1.0</td>
      <td>1.0</td>
      <td>Allison, Master. Hudson Trevor</td>
      <td>male</td>
      <td>0.9167</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>113781</td>
      <td>151.5500</td>
      <td>C</td>
      <td>S</td>
      <td>11</td>
      <td>NaN</td>
      <td>Montreal, PQ / Chesterville, ON</td>
      <td>0.0</td>
      <td>C22 C26</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>Allison, Miss. Helen Loraine</td>
      <td>female</td>
      <td>2.0000</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>113781</td>
      <td>151.5500</td>
      <td>C</td>
      <td>S</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Montreal, PQ / Chesterville, ON</td>
      <td>1.0</td>
      <td>C22 C26</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>Allison, Mr. Hudson Joshua Creighton</td>
      <td>male</td>
      <td>30.0000</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>113781</td>
      <td>151.5500</td>
      <td>C</td>
      <td>S</td>
      <td>NaN</td>
      <td>135.0</td>
      <td>Montreal, PQ / Chesterville, ON</td>
      <td>0.0</td>
      <td>C22 C26</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1.0</td>
      <td>0.0</td>
      <td>Allison, Mrs. Hudson J C (Bessie Waldo Daniels)</td>
      <td>female</td>
      <td>25.0000</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>113781</td>
      <td>151.5500</td>
      <td>C</td>
      <td>S</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Montreal, PQ / Chesterville, ON</td>
      <td>1.0</td>
      <td>C22 C26</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.groupby('cabin')['survived'].mean()
```




    cabin
    A    0.500000
    B    0.723077
    C    0.606383
    D    0.695652
    E    0.731707
    F    0.619048
    G    0.600000
    T    0.000000
    n    0.302761
    Name: survived, dtype: float64




```python
df.loc[df['pclass']==1]['survived'].mean()
```




    0.6191950464396285




```python
df.loc[df['pclass']==2]['survived'].mean()
```




    0.4296028880866426




```python
df.loc[df['pclass']==3]['survived'].mean()
```




    0.2552891396332863




```python
group_1 = df.groupby('pclass').name.count()
group_1.plot(kind = 'bar')
```




    <matplotlib.axes._subplots.AxesSubplot at 0xac3dac8>




![png](output_24_1.png)



```python
sum(df['age'].isnull())
```




    264




```python
df['age'].mean()
```




    29.8811345124283




```python
df['age'].hist()
```




    <matplotlib.axes._subplots.AxesSubplot at 0x9c868d0>




![png](output_27_1.png)



```python
bins = [0, 12, 18, 34, 50, 65,80]
```


```python
age_range = ['child', 'teen', 'youngadt', 'adult', 'older''aged'] 
```


```python
df['age_range'] = pd.cut(df['age'], bins, labels=group_names)
```


```python
pd.value_counts(df['age_range'])
```




    C    506
    D    252
    b     99
    A     94
    E     85
    F     10
    Name: age_range, dtype: int64




```python
df['age'].dropna().hist(bins = 16, range = (0, 80), alpha = 0.5)
```




    <matplotlib.axes._subplots.AxesSubplot at 0x9e07cf8>




![png](output_32_1.png)



```python
df.groupby('age_range')['survived'].mean()
```




    age_range
    A    0.574468
    C    0.379447
    D    0.404762
    E    0.423529
    F    0.200000
    b    0.414141
    Name: survived, dtype: float64




```python
df.groupby('sex-val')['survived'].mean()
```




    sex-val
    0.0    0.190985
    1.0    0.727468
    Name: survived, dtype: float64




```python
df.groupby('sibsp')['survived'].mean()
```




    sibsp
    0.0    0.346801
    1.0    0.510972
    2.0    0.452381
    3.0    0.300000
    4.0    0.136364
    5.0    0.000000
    8.0    0.000000
    Name: survived, dtype: float64




```python
df.groupby('parch')['survived'].mean()
```




    parch
    0.0    0.335329
    1.0    0.588235
    2.0    0.504425
    3.0    0.625000
    4.0    0.166667
    5.0    0.166667
    6.0    0.000000
    9.0    0.000000
    Name: survived, dtype: float64




```python
df.corr()
```




<div>
<style>
    .dataframe thead tr:only-child th {
        text-align: right;
    }

    .dataframe thead th {
        text-align: left;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>pclass</th>
      <th>survived</th>
      <th>age</th>
      <th>sibsp</th>
      <th>parch</th>
      <th>fare</th>
      <th>body</th>
      <th>sex-val</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>pclass</th>
      <td>1.000000</td>
      <td>-0.312469</td>
      <td>-0.408106</td>
      <td>0.060832</td>
      <td>0.018322</td>
      <td>-0.558629</td>
      <td>-0.034642</td>
      <td>-0.124617</td>
    </tr>
    <tr>
      <th>survived</th>
      <td>-0.312469</td>
      <td>1.000000</td>
      <td>-0.055513</td>
      <td>-0.027825</td>
      <td>0.082660</td>
      <td>0.244265</td>
      <td>NaN</td>
      <td>0.528693</td>
    </tr>
    <tr>
      <th>age</th>
      <td>-0.408106</td>
      <td>-0.055513</td>
      <td>1.000000</td>
      <td>-0.243699</td>
      <td>-0.150917</td>
      <td>0.178739</td>
      <td>0.058809</td>
      <td>-0.063646</td>
    </tr>
    <tr>
      <th>sibsp</th>
      <td>0.060832</td>
      <td>-0.027825</td>
      <td>-0.243699</td>
      <td>1.000000</td>
      <td>0.373587</td>
      <td>0.160238</td>
      <td>-0.099961</td>
      <td>0.109609</td>
    </tr>
    <tr>
      <th>parch</th>
      <td>0.018322</td>
      <td>0.082660</td>
      <td>-0.150917</td>
      <td>0.373587</td>
      <td>1.000000</td>
      <td>0.221539</td>
      <td>0.051099</td>
      <td>0.213125</td>
    </tr>
    <tr>
      <th>fare</th>
      <td>-0.558629</td>
      <td>0.244265</td>
      <td>0.178739</td>
      <td>0.160238</td>
      <td>0.221539</td>
      <td>1.000000</td>
      <td>-0.043110</td>
      <td>0.185523</td>
    </tr>
    <tr>
      <th>body</th>
      <td>-0.034642</td>
      <td>NaN</td>
      <td>0.058809</td>
      <td>-0.099961</td>
      <td>0.051099</td>
      <td>-0.043110</td>
      <td>1.000000</td>
      <td>0.015903</td>
    </tr>
    <tr>
      <th>sex-val</th>
      <td>-0.124617</td>
      <td>0.528693</td>
      <td>-0.063646</td>
      <td>0.109609</td>
      <td>0.213125</td>
      <td>0.185523</td>
      <td>0.015903</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
import statsmodels.formula.api as sm
```


```python
result = sm.ols(formula='survived ~ sex-val + fare', data=df).fit()
```


```python
result.summary
```




    <bound method OLSResults.summary of <statsmodels.regression.linear_model.OLSResults object at 0x000000000CBEC6D8>>




```python
df.boxplot(column = 'fare', by = 'pclass')
```




    <matplotlib.axes._subplots.AxesSubplot at 0xcf46b38>




![png](output_41_1.png)



```python
df.boxplot(column = 'fare', by = 'survived')
```




    <matplotlib.axes._subplots.AxesSubplot at 0xde80550>




![png](output_42_1.png)



```python

```
